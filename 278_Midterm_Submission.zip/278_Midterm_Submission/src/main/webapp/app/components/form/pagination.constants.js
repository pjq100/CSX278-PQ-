(function() {
    'use strict';

    angular
        .module('278MidtermJHipsterApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
