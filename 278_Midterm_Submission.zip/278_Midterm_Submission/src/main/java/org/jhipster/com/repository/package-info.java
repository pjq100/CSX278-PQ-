/**
 * Spring Data JPA repositories.
 */
package org.jhipster.com.repository;
